/* =============================================
   ESAPA CRM v2 — app.js
   Confirmación de Entrevistas
   ============================================= */

/* ────────────────────────────────────────────
   CONFIGURACIÓN — EDITÁ SOLO ESTA SECCIÓN
   ──────────────────────────────────────────── */
const CONFIG = {
  // URL de tu Google Apps Script
  GOOGLE_SCRIPT_URL: "https://script.google.com/macros/s/TU_URL_AQUI/exec",

  // Mensaje de WhatsApp — variables disponibles:
  // {nombre}, {curso}, {horario}, {promocion}, {asesor}
  WSP_MENSAJE: `¡Hola {nombre}! 👋

Te contactamos desde *ESAPA Instituto* para confirmar tu entrevista. 📋

Estos son tus datos registrados:
• *Curso de interés:* {curso}
• *Horario preferido:* {horario}
• *Promoción:* {promocion}

Tu asesor/a *{asesor}* se va a comunicar con vos a la brevedad para coordinar los detalles.

¡Muchas gracias por tu interés! 🎓`,
};
/* ─────────────────── FIN CONFIGURACIÓN ─────────────────── */


/* ── Estado global ── */
let datosEntrevista = {};

/* ── Referencia a la pestaña de WhatsApp (se reutiliza siempre) ── */
let wspTab = null;

/* ── Shortcut DOM ── */
const $ = id => document.getElementById(id);

const cardForm    = $("card-form");
const cardConfirm = $("card-confirm");
const cardSuccess = $("card-success");
const stepDots    = [$("step-dot-1"), $("step-dot-2"), $("step-dot-3")];
const stepLines   = document.querySelectorAll(".step-line");

/* ════════════════════════════════════════
   BARRA DE PASOS
════════════════════════════════════════ */
function setStep(n) {
  stepDots.forEach((dot, i) => {
    dot.classList.remove("active", "done");
    if (i + 1 < n)  dot.classList.add("done");
    if (i + 1 === n) dot.classList.add("active");
  });
  stepLines.forEach((line, i) => {
    line.classList.toggle("done", i + 1 < n);
  });
}

/* ════════════════════════════════════════
   VALIDACIÓN
════════════════════════════════════════ */
const CAMPOS_REQUERIDOS = ["nombre", "telefono", "edad", "curso", "ocupacion", "horario", "asesor"];

function clearErrors() {
  CAMPOS_REQUERIDOS.forEach(id => {
    const e = $(`err-${id}`);
    const i = $(id);
    if (e) e.textContent = "";
    if (i) i.classList.remove("error");
  });
  const wrap = $("tel-wrap");
  if (wrap) wrap.style.outline = "";
}

function showError(campo, msg) {
  const e = $(`err-${campo}`);
  const i = $(campo);
  if (e) e.textContent = msg;
  if (i) i.classList.add("error");
}

function validarFormulario() {
  clearErrors();
  let ok = true;

  const nombre = $("nombre").value.trim();
  if (!nombre)            { showError("nombre", "El nombre es requerido."); ok = false; }
  else if (nombre.length < 3) { showError("nombre", "Ingresá el nombre completo."); ok = false; }

  const tel = $("telefono").value.trim().replace(/\D/g, "");
  if (!tel)                         { showError("telefono", "El teléfono es requerido."); ok = false; }
  else if (tel.length < 8 || tel.length > 13) { showError("telefono", "Número inválido. Ej: 2616123456"); ok = false; }

  const edad = parseInt($("edad").value);
  if (!edad)              { showError("edad", "La edad es requerida."); ok = false; }
  else if (edad < 14 || edad > 99) { showError("edad", "Ingresá una edad válida."); ok = false; }

  const curso = $("curso").value;
  if (!curso)             { showError("curso", "Seleccioná un curso."); ok = false; }

  const ocupacion = $("ocupacion").value.trim();
  if (!ocupacion)         { showError("ocupacion", "La ocupación es requerida."); ok = false; }

  const horario = $("horario").value.trim();
  if (!horario)           { showError("horario", "El horario es requerido."); ok = false; }

  const asesor = $("asesor").value.trim();
  if (!asesor)            { showError("asesor", "El nombre del asesor es requerido."); ok = false; }

  return ok;
}

/* ════════════════════════════════════════
   PASO 1 → 2
════════════════════════════════════════ */
$("btn-continuar").addEventListener("click", () => {
  if (!validarFormulario()) return;

  const cursoSel = $("curso").value;
  const cursoFinal = cursoSel === "Otro"
    ? ($("otro-curso").value.trim() || "Otro")
    : cursoSel;

  datosEntrevista = {
    nombre:    $("nombre").value.trim(),
    telefono:  $("telefono").value.trim().replace(/\D/g, ""),
    edad:      $("edad").value.trim(),
    curso:     cursoFinal,
    ocupacion: $("ocupacion").value.trim(),
    horario:   $("horario").value.trim(),
    promocion: $("promocion").value.trim() || "Sin promoción",
    asesor:    $("asesor").value.trim(),
    timestamp: new Date().toISOString(),
  };

  const filas = [
    ["Nombre",    datosEntrevista.nombre],
    ["Teléfono",  "+54 " + datosEntrevista.telefono],
    ["Edad",      datosEntrevista.edad + " años"],
    ["Curso",     datosEntrevista.curso],
    ["Ocupación", datosEntrevista.ocupacion],
    ["Horario",   datosEntrevista.horario],
    ["Promoción", datosEntrevista.promocion],
    ["Asesor",    datosEntrevista.asesor],
  ];

  $("confirm-table").innerHTML = filas.map(([k, v]) => `
    <div class="confirm-row">
      <span class="confirm-key">${k}</span>
      <span class="confirm-val">${v}</span>
    </div>
  `).join("");

  cardForm.classList.add("hidden");
  cardConfirm.classList.remove("hidden");
  setStep(2);
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ── Volver ── */
$("btn-volver").addEventListener("click", () => {
  cardConfirm.classList.add("hidden");
  cardForm.classList.remove("hidden");
  setStep(1);
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ── Campo "Otro" curso ── */
$("curso").addEventListener("change", function () {
  $("grupo-otro").classList.toggle("hidden", this.value !== "Otro");
});

/* ════════════════════════════════════════
   PASO 2 → 3: GUARDAR + ÉXITO
════════════════════════════════════════ */
$("btn-guardar").addEventListener("click", async () => {
  const btn   = $("btn-guardar");
  const texto = $("btn-guardar-text");
  const spin  = $("spinner");

  btn.disabled = true;
  texto.textContent = "Guardando...";
  spin.classList.remove("hidden");

  try {
    await enviarASheets(datosEntrevista);

    const mensaje = CONFIG.WSP_MENSAJE
      .replace("{nombre}",    datosEntrevista.nombre)
      .replace("{curso}",     datosEntrevista.curso)
      .replace("{horario}",   datosEntrevista.horario)
      .replace("{promocion}", datosEntrevista.promocion)
      .replace("{asesor}",    datosEntrevista.asesor);

    $("success-nombre").textContent = datosEntrevista.nombre;
    $("wsp-preview").textContent = mensaje;

    // Guardar URL y mensaje para el botón
    const tel    = "54" + datosEntrevista.telefono;
    const wspUrl = `https://web.whatsapp.com/send?phone=${tel}&text=${encodeURIComponent(mensaje)}`;

    $("btn-wsp").onclick = () => abrirWhatsApp(wspUrl);

    cardConfirm.classList.add("hidden");
    cardSuccess.classList.remove("hidden");
    setStep(3);
    window.scrollTo({ top: 0, behavior: "smooth" });
    showToast("✅ Entrevista registrada exitosamente", "success");

  } catch (err) {
    showToast("⚠️ Error al guardar. Verificá la conexión.", "error");
    console.error(err);
  } finally {
    btn.disabled = false;
    texto.textContent = "Guardar y contactar";
    spin.classList.add("hidden");
  }
});

/* ════════════════════════════════════════
   WHATSAPP — PESTAÑA ÚNICA REUTILIZABLE
   ════════════════════════════════════════
   Cómo funciona:
   - Primera vez: abre una pestaña nueva llamada "esapa_wsp"
   - Siguientes veces: el navegador reutiliza esa misma pestaña
     y la recarga con el nuevo número y mensaje
   - Si el usuario cerró la pestaña manualmente, la vuelve a abrir
════════════════════════════════════════ */
function abrirWhatsApp(url) {
  // window.open con nombre fijo = siempre la misma pestaña
  wspTab = window.open(url, "esapa_wsp");

  // Si el navegador bloqueó el popup, aviso al usuario
  if (!wspTab || wspTab.closed || typeof wspTab.closed === "undefined") {
    showToast("⚠️ Permití las ventanas emergentes en tu navegador para esta página.", "error");
  }

  // Actualizar el hint según si es la primera vez o no
  const hint = $("wsp-hint");
  if (hint) hint.textContent = "✅ La pestaña de WhatsApp se actualizó con el nuevo contacto.";
}

/* ── Nueva entrevista ── */
$("btn-nuevo").addEventListener("click", () => {
  const campos = ["nombre","telefono","edad","ocupacion","horario","promocion","asesor","otro-curso"];
  campos.forEach(id => { const el = $(id); if (el) el.value = ""; });
  $("curso").value = "";
  $("grupo-otro").classList.add("hidden");
  clearErrors();
  datosEntrevista = {};

  // Resetear hint
  const hint = $("wsp-hint");
  if (hint) hint.textContent = "💡 La primera vez abre una nueva pestaña. Las siguientes, recarga la misma.";

  cardSuccess.classList.add("hidden");
  cardForm.classList.remove("hidden");
  setStep(1);
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ════════════════════════════════════════
   GOOGLE SHEETS
════════════════════════════════════════ */
async function enviarASheets(datos) {
  if (CONFIG.GOOGLE_SCRIPT_URL.includes("TU_URL_AQUI")) {
    console.warn("⚠️ MODO DEMO: configurá la URL de Google Apps Script.");
    await new Promise(r => setTimeout(r, 1000));
    return { demo: true };
  }

  const params = new URLSearchParams();
  Object.entries(datos).forEach(([k, v]) => params.append(k, v));

  await fetch(CONFIG.GOOGLE_SCRIPT_URL, {
    method: "POST",
    mode: "no-cors",
    body: params,
  });

  return { ok: true };
}

/* ════════════════════════════════════════
   CHATBOT
════════════════════════════════════════ */
const chatWindow  = $("chatbot-window");
const chatTrigger = $("chatbot-trigger");
const chatClose   = $("chat-close");
const chatInput   = $("chat-input");
const chatSend    = $("chat-send");
const chatMsgs    = $("chat-messages");

chatTrigger.addEventListener("click", () => chatWindow.classList.toggle("hidden"));
chatClose.addEventListener("click",   () => chatWindow.classList.add("hidden"));
chatSend.addEventListener("click", enviarMsgChat);
chatInput.addEventListener("keydown", e => { if (e.key === "Enter") enviarMsgChat(); });

function enviarMsgChat() {
  const msg = chatInput.value.trim();
  if (!msg) return;
  agregarBurbuja(msg, "user");
  chatInput.value = "";
  const typing = agregarBurbuja("···", "typing");
  setTimeout(() => {
    typing.remove();
    agregarBurbuja(responderChat(msg), "bot");
  }, 700);
}

function agregarBurbuja(texto, tipo) {
  const el = document.createElement("div");
  el.className = `chat-bubble ${tipo}`;
  el.textContent = texto;
  chatMsgs.appendChild(el);
  chatMsgs.scrollTop = chatMsgs.scrollHeight;
  return el;
}

function responderChat(msg) {
  const m = msg.toLowerCase();
  if (/hola|buenas|hey/i.test(m))
    return "¡Hola! ¿En qué puedo ayudarte? Puedo orientarte sobre cómo completar el formulario o responder dudas sobre los cursos.";
  if (/entrevista|registr/i.test(m))
    return "Para registrar una entrevista completá los 7 campos del formulario: Nombre, Teléfono, Edad, Curso, Ocupación, Horario y Asesor. ¡Es rápido!";
  if (/curso|carrera/i.test(m))
    return "Ofrecemos Administración, Marketing Digital, Diseño Gráfico, Programación Web, Enfermería, Gastronomía y más. Podés elegir 'Otro' si el curso no está en la lista.";
  if (/whatsapp|mensaje|contacto|enviar/i.test(m))
    return "Al guardar la entrevista, el botón de WhatsApp ya tiene el mensaje armado con los datos del candidato. La primera vez abre una pestaña nueva, las siguientes recarga la misma. 📲";
  if (/teléfono|numero|cel/i.test(m))
    return "Ingresá el número sin el 0 inicial y sin el 15. Por ejemplo: 0261 15-612-3456 → escribís 2616123456.";
  if (/horario/i.test(m))
    return "En el campo Horario podés escribir libremente: 'Mañana', 'Tarde', 'Noche', '18hs', lo que el candidato prefiera.";
  if (/promocion|promo|descuento/i.test(m))
    return "En Promoción anotás cualquier oferta activa que le estés comunicando al candidato, por ejemplo: '50% off', '3 cuotas sin interés', etc. Es opcional.";
  if (/asesor/i.test(m))
    return "En Asesor escribís tu nombre o el de quien está haciendo la entrevista, para poder hacer seguimiento después.";
  if (/sheets|excel|planilla/i.test(m))
    return "Los datos se guardan automáticamente en Google Sheets al tocar 'Guardar y contactar'. ¡Nada a mano!";
  if (/gracias|ok|listo|perfecto/i.test(m))
    return "¡De nada! Si necesitás algo más, acá estoy. 😊";
  return `No tengo una respuesta específica para "${msg}", pero podés consultarle directamente a tu equipo. ¿Puedo ayudarte con el formulario?`;
}

/* ════════════════════════════════════════
   UTILIDADES
════════════════════════════════════════ */
function showToast(msg, tipo = "") {
  const t = $("toast");
  t.textContent = msg;
  t.className = `toast ${tipo}`;
  t.classList.remove("hidden");
  setTimeout(() => t.classList.add("hidden"), 3500);
}

$("year").textContent = new Date().getFullYear();
setStep(1);
